ADESA HQ carousel concept assets

slides/: Five individually cropped panels from the previously generated composite storyboard. These are MOCKUPS with text and buttons baked into the images, not clean production background photos. Leadway scene is AI-generated and must not be presented as authentic campaign photography. Replace with approved real campaign imagery before production.

logos/: Original uploaded official logos, preserved unchanged.

For the live website, implement headlines and buttons as HTML overlays, not as text embedded in images. HQ logo animation must be built separately using the HQ logo asset.
